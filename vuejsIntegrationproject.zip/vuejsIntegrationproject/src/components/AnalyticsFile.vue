<template>
  <!-- <div id="app"> -->
  <div class="analytics-main">
    <span class="analytics-page-header">Contract Details</span>
    <!-- <button style="float:right" class="btn-solid">Upload Document</button> -->
    <div class="contract-card-container">
      <div
        class="contract-card"
        v-for="option in dataOptions"
        :key="option.title"
      >
        <div class="contract-title">{{ option.title }}</div>

        <div class="contract-main">
          <div class="contract-left">
            <span class="contract-number">{{ option.total }}</span> 
            <span class="contract-label">Contracts</span>
          </div>
          <div class="contract-info">
            <div>{{ option.str1 }}</div>

            <div>{{ option.str2 }}</div>
          </div>
        </div>

      </div>
    </div>
  </div>
</template>

<script>
export default {
  // register the component

  data() {
    return {
      dataOptions: [
        {
          title: "Active Contracts",
          total: "10,152",
          str1: "10 added in last hour",
          str2: "12 added today",
        },
        {
          title: "Pending Contracts",
          total: "2,718",
          str1: "15 added in last hour",
          str2: "12 added today",
        },
        {
          title: "Signed Contracts",
          total: "23,566",
          str1: "13 added in last hour",
          str2: "11 added today",
        },
        {
          title: "Cancelled Contracts",
          total: "876",
          str1: "10 added in last hour",
          str2: "15 added today",
        },
      ],
      // define the default value
      value: null,
      // define options
    };
  },

  computed: {},
};
</script>
