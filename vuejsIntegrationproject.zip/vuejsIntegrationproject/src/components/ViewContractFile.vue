<template>
  <div style="display: flex; flex-direction: column; padding-left: 5px">
    <div v-if="loadingAccount" class="loading-indicator">
      Loading Accounts...
    </div>
    <div v-else>
      <div v-for="(account, index) in accountOptions" :key="account">
        <button class="filebtn filebtn-l1" @click="toggleArrow(account, index)">
          <span
            :class="selectedAccount !== account ? 'arrow-right' : 'arrow-down'"
          ></span>
          <i style="color: #5f249f" class="bi bi-person-fill"></i>
          <span class="account_name">{{ account }}</span>
        </button>

        <div v-if="selectedAccount === account" style="margin-left: 20px">
          <!-- <div v-if="loading" class="loading-indicator">
          Loading...
        </div>
        <div v-else> -->
          <div v-if="loadingOpportunity" class="loading-indicator">
            Loading Opportunities...
          </div>

          <!-- Opportunity Options -->
          <div v-else>
            <div v-for="opportunity in opportunityOptions" :key="opportunity">
              <button
                class="filebtn filebtn-l2"
                @click="toggleArrowOpportunity(opportunity, account)"
              >
                <span
                  :class="
                    selectedOpportunity !== opportunity
                      ? 'arrow-right'
                      : 'arrow-down'
                  "
                ></span>
                <i style="color: #c58fff" class="bi bi-grid-fill"></i>
                <span>{{ opportunity }}</span>
              </button>

              <div
                v-if="selectedOpportunity === opportunity"
                style="margin-left: 20px"
              >
                <div v-if="loadingContract" class="loading-indicator">
                  Loading Contracts...
                </div>

                <!-- Contract Options -->
                <div v-else>
                  <div v-for="contract in contractOptions" :key="contract">
                    <button
                      class="filebtn"
                      @click="
                        toggleArrowContract(contract, opportunity, account)
                      "
                    >
                      <span
                        :class="
                          selectedContract !== contract
                            ? 'arrow-right'
                            : 'arrow-down'
                        "
                      ></span>
                      <i class="bi bi-folder-fill"></i>
                      <span>{{ contract }}</span>
                    </button>

                    <div
                      v-if="selectedContract === contract"
                      style="margin-left: 20px"
                    >
                      <div v-if="loadingCategory" class="loading-indicator">
                        Loading Categories...
                      </div>

                      <!-- Category Options -->
                      <div v-else>
                        <div
                          v-for="category in categoryOptions"
                          :key="category"
                        >
                          <button
                            class="filebtn"
                            @click="
                              toggleArrowCategory(
                                category,
                                contract,
                                opportunity,
                                account
                              )
                            "
                          >
                            <span
                              :class="
                                selectedCategory !== category
                                  ? 'arrow-right'
                                  : 'arrow-down'
                              "
                            ></span>
                            <i class="bi bi-folder-fill"></i>
                            <span>{{ category }}</span>
                          </button>

                          <div
                            v-if="selectedCategory === category"
                            style="margin-left: 20px"
                          >
                            <div
                              v-for="folderPath in folderPathOptions"
                              :key="folderPath"
                              style="color: #636363; display: flex"
                            >
                              <i class="bi bi-file-text"></i>{{ folderPath }}
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
  <!-- </div> -->
</template>
<script>
import FileMixin from "@/mixins/FileMixin";
export default {
  mixins: [FileMixin],
  data() {
    return {
      accountOptions: [],
      opportunityOptions: [],
      contractOptions: [],
      categoryOptions: [],
      folderPathOptions: [],

      selectedAccount: "",
      selectedOpportunity: "",
      selectedContract: "",
      selectedCategory: "",

      accountArrows: {},
      filters: {},
    };
  },
  created() {
    this.getFolderView();
  },
  methods: {
    toggleArrow(account, index) {
      this.accountArrows[index] =
        this.accountArrows[index] === "down" ? "right" : "down";
      this.selectedAccount =
        this.accountArrows[index] === "down" ? account : "";
      this.getFolderView(account);
    },

    toggleArrowOpportunity(opportunity, account) {
      this.selectedOpportunity =
        this.selectedOpportunity === opportunity ? "" : opportunity;
      this.getFolderView(account, opportunity);
    },

    toggleArrowContract(contract, opportunity, account) {
      this.selectedContract =
        this.selectedContract === contract ? "" : contract;
      this.getFolderView(account, opportunity, contract);
    },

    toggleArrowCategory(category, contract, opportunity, account) {
      this.selectedCategory =
        this.selectedCategory === category ? "" : category;
      this.getFolderView(account, opportunity, contract, category);
    },
  },
};
</script>
<style scoped>
* {
  font-family: "Rubik", sans-serif;
  font-size: 14px;
}

.arrow-right::before {
  content: "►";
  font-size: 14px;
  margin-right: 5px;
}

.arrow-down::before {
  content: "▼";
  font-size: 14px;
  margin-right: 5px;
}

button {
  width: 95%;
  border-radius: 5px;
  transition: 0.1s ease;
}
button:hover {
  background-color: #e9e4ef89;
}
/* .loading-indicator {
 
  font-weight: bold;
  margin: 10px 0;
} */
</style>