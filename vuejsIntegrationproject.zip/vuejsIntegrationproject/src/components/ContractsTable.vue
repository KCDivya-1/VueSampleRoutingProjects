<template>
  <div>
    <div class="heading-class">
      <span class="analytics-page-header">All Documents</span>
      <div style="display: flex; gap: 10px;">
        <input class="table-search" v-model="searchVal" placeholder="Search Table..." >
        <div class="tableActionButtons">
          <!-- <button class="fillBtn" id="typeOfAction">+ create folder</button>
          <button class="fillBtn" id="typeOfAction">Filters</button> -->
          <button
            class="fillBtn"
            id="typeOfAction"
            :disabled="!currentEditId"
            @click="updateFileName"
          >
            Update
          </button>
        </div>
      </div>

    </div>

    <b-overlay :show="isBusyLoad" rounded="sm">
      <b-table
        class="tablemessage"
        :items="fetchDocuments"
        :fields="fields"
        :per-page="perPage"
        responsive
        small
        :current-page="currentPage"
        :filter="searchVal"
        :filter-included-fields="filterOn"
        :sortBy="sortBy"
        :sortDesc="sortDesc"
        show-empty
        emptyText="No Data Found"
        @update:sortBy="sortBy = $event"
        @update:sortDesc="sortDesc = $event"
      >
        <!-- <template #cell(selection)="data">
          <b-form-group>
            <b-form-checkbox :key="data.item.id" :value="data.item.id"  v-model="selectedRecord">
            </b-form-checkbox>
          </b-form-group> </template
        > -->
        <template #cell(File_Name)="data">
          <div>
            <input
              v-if="isEditing(data.item.id)"
              v-model="data.item.File_Name"
              class="sla-select"
              placeholder=""
            />
            <span v-else>{{ data.item.File_Name }}</span>
          </div>
          <span
            class="text-danger diamond-error-style"
            v-if="!data.item.File_Name && isClicked && isEditing(data.item.id)"
          >
            The Field is required
          </span>
        </template>

        <template #cell(Action)="data">
          <div style="display: flex; gap: 6px">
            <div class="row-action">
              <b-icon-eye
                style="color: #5f249f; cursor: pointer"
                v-b-tooltip.hover
                title="view the Document"
                @click="viewFile(data.item.id)"
              />
            </div>
            <div class="row-action">
              <b-icon-pencil-square
                style="color: #5f249f; cursor: pointer"
                v-b-tooltip.hover
                title="Edit the Document"
                @click="toggleEdit(data.item.id)"
              />
            </div>
            <!-- <div>
              <b-icon-pencil-square
                style="color: #5f249f; cursor: pointer"
                v-b-tooltip.hover
                title="Edit the Document"
              
              />
            </div> -->
            <!-- <div>
              <b-icon-trash-fill
                style="color: #5f249f; cursor: pointer"
                v-b-tooltip.hover
                title="Delete the Record"
              />
            </div> -->
            <div class="row-action">
              <!-- {{data.item.id}} -->
              <b-icon-download
                v-b-tooltip.hover
                title="Download the Document"
                style="color: #5f249f; cursor: pointer"
                @click="downloadFile(data.item.id)"
              />
            </div>
          </div>
        </template>
      </b-table>

      <div class="tableFooter" style="display: flex">
        <b-pagination
          v-model="currentPage"
          :per-page="perPage"
          :total-rows="totalRows()"
          aria-controls="my-table"
        ></b-pagination>

        <b-col sm="3">
          <b-form-group
            label="Per page"
            label-for="per-page-select"
            label-cols-sm="6"
            label-cols-md="4"
            label-cols-lg="3"
            label-align-sm="right"
            label-size="sm"
            class="mb-0"
          >
            <b-form-select
              id="per-page-select"
              v-model="perPage"
              :options="pageOptions"
              size="sm"
            ></b-form-select>
          </b-form-group>
        </b-col>
      </div>
    </b-overlay>
  </div>
</template>
<script>
import Swal from "sweetalert2";
import { success } from "@/constants/observable";
import {
  GET_CONTRACT_DOCUMENTS,
  GET_DOCUMENT_URL,
  UPDATE_FILENAME,
} from "@/constants/graphql";
export default {
  data() {
    return {
      isClicked: false,
      currentEditId: null,
      selectedRecord: "",
      id: "",
      url: "",
      items: [],
      fetchDocuments: [],
      countRecords: 0,
      isBusyLoad: false,
      perPage: 5,
      currentPage: 1,
      pageOptions: [5, 10, 25, 50, { value: 100, text: "Maximum" }],
      sortBy: "Submission_Date",
      sortDesc: true,
      searchVal: "",
      filterOn: ["Contract_ID", "OpportunityID", "File_Name", "Account_Name"],
      fields: [
        // {
        //   label: "",
        //   key: "selection",
        //   thClass: "thead",
        //   thStyle: "background: #5f249f;  color: white",
        //   // stickyColumn: true,
        // },
        {
          key: "Contract_ID",
          label: "Contract ID",
          sortable: true,
        },
        {
          key: "OpportunityID",
          label: "Opp ID",
          sortable: true,
        },
        {
          key: "File_Name",
          label: "File Name",
          sortable: true,
        },
        {
          label: "Account Name",
          key: "Account_Name",
          sortable: true,
        },
        // {
        //   key: "EndDate",
        //   label: "End Date",
        //   sortable: true,
        // },
        // {
        //   key: "Status",
        //   label: "Status",
        //   sortable: true,
        // },
        {
          key: "Action",
          label: "Action",
          sortable: true,
        },
      ],
    };
  },
  apollo: {
    fetchDocuments: {
      query: GET_CONTRACT_DOCUMENTS,
      skip: true,
      variables() {
        return {
          filters: "{}",
        };
      },
    },
    fetchDocumentURL: {
      query: GET_DOCUMENT_URL,
      skip: true,
      variables() {
        return {
          fileID: "",
        };
      },
    },
    updateBlobName: {
      query: UPDATE_FILENAME,
      skip: true,
      variables() {
        return {
          updateType: "file",
          fileID: "",
          requestedName: "",
        };
      },
    },
  },
  created() {
    this.getData();
  },
  computed: {
    // rows() {
    //   return this.items.length;
    // },
  },
  mounted() {},
  methods: {
    isEditing(id) {
      return this.currentEditId === id;
    },
    toggleEdit(id) {
      if (this.currentEditId === id) {
        this.currentEditId = null;
      } else {
        this.currentEditId = id;
      }
    },
    async updateFileName() {
      this.isClicked = true;
      const item = this.fetchDocuments.find(
        (doc) => doc.id === this.currentEditId
      );
      if (!item || !item.File_Name) {
        console.log("The Field is required");
        return;
      }
      try {
        this.$apollo.queries.updateBlobName.skip = false;
        await this.$apollo.queries.updateBlobName.refetch({
          fileID: item.id,
          requestedName: item.File_Name,
        });

        console.log("File name", item.File_Name);
        success("File name updated successfully");
        this.currentEditId = null;
        this.isClicked = false;
      } catch (error) {
        console.error("Error", error);
      }
    },

    totalRows() {
      return Number(this.countRecords);
    },
    async getData() {
      this.isBusyLoad = true;
      try {
        this.$apollo.queries.fetchDocuments.skip = false;
        await this.$apollo.queries.fetchDocuments.refetch();
        console.log("hhhhhhhhhhhhhhhhhh", this.fetchDocuments);
        this.countRecords = this.fetchDocuments.length;
        this.isBusyLoad = false;
      } catch (error) {
        console.log(error);
        this.isBusyLoad = false;
      }
    },

    async fetchFileUrl(id) {
      console.log("dddddddddddddd", id);
      try {
        this.$apollo.queries.fetchDocumentURL.skip = false;
        const response = await this.$apollo.queries.fetchDocumentURL.refetch({
          fileID: id,
        });
        console.log("response", response);
        return response.data.fetchDocumentURL.url;
      } catch (error) {
        console.error("Error ", error);
        return null;
      }
    },

    async downloadFile(id) {
      try {
        const url = await this.fetchFileUrl(id);
        if (!url) throw new Error("URL not available for download.");

        // Fetch the file as a Blob
        const response = await fetch(url);
        if (!response.ok) throw new Error("Failed to fetch the file.");

        const blob = await response.blob();
        const downloadUrl = URL.createObjectURL(blob);

        const link = document.createElement("a");
        link.href = downloadUrl;
        link.download = "test.pdf";
        document.body.appendChild(link);
        link.click();

        setTimeout(() => {
          Swal.fire({
            position: "top-end",
            icon: "success",
            title: "File Successfully Downloaded",
            showConfirmButton: false,
            timer: 1750,
          });
        }, 1500);

        URL.revokeObjectURL(downloadUrl);
        document.body.removeChild(link);
      } catch (error) {
        console.error("Error downloading file:", error);
      }
    },

    async viewFile(id) {
      try {
        const url = await this.fetchFileUrl(id);
        if (url) {
          window.open(url, "_blank");
        } else {
          console.error("URL not available");
        }
      } catch (error) {
        console.error("Error", error);
      }
    },
  },
};
</script>
<style scoped>

.table th {
  background: white;
}
:deep().tablemessage .sr-only {
  display: none;
}
:deep() .page-item.active .page-link {
  background-color: white !important;
  color: #5f249f;
  border-color: #d9d9d9 !important;
}
:deep() .page-link {
  color: #969696;
  font-size: 12px;
}

:deep() .page-item.disabled .page-link {
  background-color: white !important;
  color: #666666;
  border-color: #d9d9d9 !important;
  font-size: 12px;
}

.form-row {
  display: flex;
  flex-wrap: wrap;
}
.custom-select.custom-select-sm {
  width: 150px;
  height: 30px;
}
.form-row > .col,
.form-row > [class*="col-"] {
  padding-right: 5px;
  padding-left: 5px;
}
.text-sm-right {
  text-align: right;
}
:deep().col-form-label-sm {
  text-align: right;
  margin-right: 6px;
}
.sectiontitle {
  margin-top: 0 !important;
}

.formAction {
  margin-top: 44px;
  position: relative;
}
.formAction {
  margin-top: 0px;
  position: relative;
  padding-bottom: 5px;
}
.formSearch {
  display: flex;
  flex-direction: column;
  width: 400px;
}
:deep().col-form-label-sm {
  text-align: left;
}
/* :deep().table.b-table > thead > tr > .b-table-sticky-column {
  z-index: 1;
  background-color: #5f249f !important;
  color: #fff;
} */

:deep().table.b-table.table-sm
  > thead
  > tr
  > [aria-sort]:not(.b-table-sort-icon-left),
.table.b-table.table-sm
  > tfoot
  > tr
  > [aria-sort]:not(.b-table-sort-icon-left) {
  background-position: right calc(0.3rem / 2) center;
  padding-right: calc(0.3rem + 0.65em);
  z-index: 1;
  background-color: #E8E3EE !important;
  color: #5f249f;
  padding: 10px;
  font-weight:600;
}

.tableActionButtons {
  display: flex;
  flex-direction: row;
  gap: 8px;
  justify-content: flex-end;
}

input.table-search {
    padding: 5px 10px;
    width: 310px;
    border: 1px solid #c9c9c9;
    border-radius: 2px;
}

.fillBtn {
  background-color: #5f249f;
  color: white;
  border-radius: 0px;
  border-top-right-radius: 20px;
  padding: 5px 40px;
  transition: 0.5s ease;
  border: 1px solid #5f249f;
}
.fillBtn:hover {
  border: 1px solid #5f249f;
  color: #5f249f;
  background-color: white;
}
.form-label {
  font-size: 14px;
  font-weight: 600;
  margin-bottom: 0px;
  color: #5f249f;
}
.sla-select {
  width: 560px;
}

.fillBtn:disabled {
  background: #e9ecef !important;
  border-color: #00000061;
  color: #000 !important;
}

.heading-class {
    display: flex;
    flex-direction: row;
    width: 100%;
    align-items: center;
    justify-content: space-between;
    gap: 10px;
    padding-bottom: 10px;
}

* { 
  font-size: 14px;
  font-family: "Open Sans", sans-serif
}

.row-action {
    border: 1px solid #E7E8EB;
    padding: 5px;
    border-radius: 5px;
    width: 25px;
    height: 25px;
    display: flex;
    align-items: center;  
}

.form-row {
  padding-left: 10px;
}
</style>