<template>
  <div class="app-navbar navbar-left">
    <div class="navbar-left-master">
      <img style="width: 90%" src="@/assets/dxc-logo-new.png" />
      <i class="bi bi-chevron-double-left"></i>
    </div>
    <hr width="90%" style="margin: 0 0 1rem 0"/>
  </div>
</template>

<script>
export default {
  data() { 
    return {}
  }
}
</script>