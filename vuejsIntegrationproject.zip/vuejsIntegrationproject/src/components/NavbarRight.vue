<template>
    <div class="app-navbar navbar-right">
      <div class="navbar-right-master">
        <div style="display:flex; gap: 20px;">
            <i style="color: #5f249f" class="bi bi-grid"></i>
            <span>Contract Document Management</span>
        </div>
        
        <div class="user-init">RK</div>
        </div>
    </div>
  </template>
  
  <script>
  export default {
    data() { 
      return {}
    }
  }
  </script>