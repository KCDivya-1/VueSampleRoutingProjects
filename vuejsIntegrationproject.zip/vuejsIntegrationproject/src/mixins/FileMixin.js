import { GET_FOLDER_VIEW } from "@/constants/graphql";

export default {
  apollo: {
    fetchFolderView: {
      query: GET_FOLDER_VIEW,
      skip: true,
      variables() {
        return {
          filters: "{}",
        };
      },
    },
  },
  data() {
    return {
      fetchFolderView: {},
      loadingAccount: false,
      loadingOpportunity: false,
      loadingContract: false,
      loadingCategory: false,
     // loading: false,
    }
  },
  methods: {
    async getFolderView(account = '', opportunity = '', contract = '', category = '') {
      try {
      
        if (account && !opportunity && !contract && !category) {
          this.loadingOpportunity = true;
        } else if (account && opportunity && !contract && !category) {
          this.loadingContract = true;
        } else if (account && opportunity && contract && !category) {
          this.loadingCategory = true;
        } else if (account && opportunity && contract && category) {
          this.loadingFolderPath = true;
        } else {
          this.loadingAccount = true;
        }

        let filters = { selectedValue: "Account_Name" };

        if (account && !opportunity && !contract && !category) {
          filters = { selectedValue: "OpportunityID", Account_Name: account };
        } else if (account && opportunity && !contract && !category) {
          filters = {
            selectedValue: "Contract_ID",
            Account_Name: account,
            OpportunityID: opportunity,
          };
        } else if (account && opportunity && contract && !category) {
          filters = {
            selectedValue: "Category",
            Account_Name: account,
            OpportunityID: opportunity,
            Contract_ID: contract,
          };
        } else if (account && opportunity && contract && category) {
          filters = {
            selectedValue: "File_Name",
            Account_Name: account,
            OpportunityID: opportunity,
            Contract_ID: contract,
            Category: category,
          };
        }

        this.$apollo.queries.fetchFolderView.skip = false;
        await this.$apollo.queries.fetchFolderView.refetch({
          filters: JSON.stringify(filters),
        });

        const resultData = this.fetchFolderView.data || [];

        if (filters.selectedValue === "Account_Name") {
          this.accountOptions = resultData;
        } else if (filters.selectedValue === "OpportunityID") {
          this.opportunityOptions = resultData;
        } else if (filters.selectedValue === "Contract_ID") {
          this.contractOptions = resultData;
        } else if (filters.selectedValue === "Category") {
          this.categoryOptions = resultData;
        } else if (filters.selectedValue === "File_Name") {
          this.folderPathOptions = resultData;
        }
      } catch (error) {
        console.error("Error fetching data", error);
      } finally {
        
        this.loadingAccount = false;
        this.loadingOpportunity = false;
        this.loadingContract = false;
        this.loadingCategory = false;
        this.loadingFolderPath = false;
      }
    },
 
    async getFolderViewOld(
      account = null,
      opportunity = null,
      contract = null,
      category = null
    ) {
      try {
        let filters = { selectedValue: "Account_Name" };

        if (account && !opportunity && !contract && !category) {
          filters = { selectedValue: "OpportunityID", Account_Name: account };
          // this.opportunityOptions = [];
          // this.contractOptions = [];
          // this.categoryOptions = [];
          // this.folderPathOptions = [];
        } else if (account && opportunity && !contract && !category) {
          filters = {
            selectedValue: "Contract_ID",
            Account_Name: account,
            OpportunityID: opportunity,
          };
          // this.contractOptions = [];
          // this.categoryOptions = [];
          // this.folderPathOptions = [];
        } else if (account && opportunity && contract && !category) {
          filters = {
            selectedValue: "Category",
            Account_Name: account,
            OpportunityID: opportunity,
            Contract_ID: contract,
          };
          // this.categoryOptions = [];
          // this.folderPathOptions = [];
        } else if (account && opportunity && contract && category) {
          filters = {
            selectedValue: "File_Name",
            Account_Name: account,
            OpportunityID: opportunity,
            Contract_ID: contract,
            Category: category,
          };
          // this.folderPathOptions = [];
        }

        this.$apollo.queries.fetchFolderView.skip = false;
        await this.$apollo.queries.fetchFolderView.refetch({
          filters: JSON.stringify(filters),
        });

        const resultData = this.fetchFolderView.data || [];

        if (filters.selectedValue === "Account_Name") {
          this.accountOptions = resultData;
        } else if (filters.selectedValue === "OpportunityID") {
          this.opportunityOptions = resultData;
        } else if (filters.selectedValue === "Contract_ID") {
          this.contractOptions = resultData;
        } else if (filters.selectedValue === "Category") {
          this.categoryOptions = resultData;
        } else if (filters.selectedValue === "File_Name") {
          this.folderPathOptions = resultData;
        }
      } catch (error) {
        console.error("Error fetching data:", error);
      }
    },
  }
}