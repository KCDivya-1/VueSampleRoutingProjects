import gql from 'graphql-tag'

export const GET_CONTRACT_DOCUMENTS = gql`
  query fetchDocuments($filters: String!) {
    fetchDocuments(filters: $filters) {
        Contract_ID
        Folder_Path
        OpportunityID
        File_Name
        Folder_ID
        Account_Name
        id
    }
  }
`
export const GET_DOCUMENT_URL = gql`
query fetchDocumentURL($fileID: String!) {
  fetchDocumentURL(fileID: $fileID) {
    url
    err
  }
}
`
export const UPDATE_FILENAME = gql`
query updateBlobName($updateType: String!,$fileID:String!,$requestedName:String!) {
  updateBlobName(updateType: $updateType,fileID:$fileID,requestedName:$requestedName) 
}
`
export const GET_FOLDER_VIEW = gql`
  query fetchFolderView($filters: String!) {
    fetchFolderView(filters: $filters) {
      success
      data
    }
  }
`