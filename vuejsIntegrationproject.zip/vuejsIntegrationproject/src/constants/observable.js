
import Swal from 'sweetalert2'


// ======================================================== Messagin Formate======================================================
export async function success(msg) {
  let confirmAction = false
  await Swal.fire({
    html: `<span style="color:#006400; font-size: 20px; font-weight: bold;">${msg}</span>`,
    // title: 'Margin Expansion Tool (MET) Notification',
    // color: '#5F249F',
    // iconColor:'#00FF00',
    // iconHtml: '<span class="material-symbols-outlined">check_circle</span>',
    imageUrl: require('@/assets/success-icon.png'),
    imageHeight: 80,
    showConfirmButton: true,
    confirmButtonText: '<strong>OK</strong>',
    customClass: {
      confirmButton: 'dxcBtn confirmBtn',
    },
  })
    .then((response) => {
      if (response.isConfirmed) {
        confirmAction = true
      }
    })
    .catch(() => {})
  return confirmAction
}

// export async function warning(msg, options = {}) {
//   let confirmAction = false
//   let swalOptions = {
//     html: `<span style="color:#F7A204; font-size: 20px; font-weight: bold;">${msg}</span>`,
//     // title: 'Margin Expansion Tool (MET) Notification',
//     // color: '#5F249F',
//     imageUrl: require('@/assets/images/warning-image.jpg'),
//     imageHeight: 80,
//     showConfirmButton: true,
//     confirmButtonText: '<strong>OK</strong>',
//     showCancelButton: true,
//     customClass: {
//       confirmButton: 'dxcBtn confirmBtn',
//     },
//   }
//   await Swal.fire({ ...swalOptions, ...options }).then((response) => {
//     if (response.isConfirmed) {
//       confirmAction = true
//     }
//   })
//   return confirmAction
// }

// //error popup message changes

// export async function errorWithYesNoBtn(msg) {
//   let isNoButtonPressed = false

//   await Swal.fire({
//     html: `<span style="color:#FF0000; font-size: 20px; font-weight: bold;">${msg}</span>`,
//     color: '#5F249F',
//     // iconColor:'#00FF00',
//     // iconHtml: '<span class="material-symbols-outlined">check_circle</span>',
//     imageUrl: require('@/assets/images/error-icon.png'),
//     imageHeight: 100,
//     showConfirmButton: true,
//     confirmButtonText: '<strong>Yes</strong>',
//     cancelButtonText: '<strong>No</strong>',
//     showCancelButton: true,
//     customClass: {
//       confirmButton: 'dxcBtn confirmBtn',
//       cancelButton: 'dxcBtn confirmBtn',
//     },
//   }).then((result) => {
//     if (!result.isConfirmed) {
//       isNoButtonPressed = true
//     }
//   })

//   return isNoButtonPressed
// }

// export function error(msg) {
//   Swal.fire({
//     html: `<span style="color:#FF0000; font-size: 20px; font-weight: bold;">${msg}</span>`,
//     color: '#5F249F',
//     // iconColor:'#00FF00',
//     // iconHtml: '<span class="material-symbols-outlined">check_circle</span>',
//     imageUrl: require('@/assets/images/error-icon.png'),
//     imageHeight: 100,
//     showConfirmButton: true,
//     confirmButtonText: '<strong>Ok</strong>',

//     customClass: {
//       confirmButton: 'dxcBtn confirmBtn',
//     },
//   })
// }
