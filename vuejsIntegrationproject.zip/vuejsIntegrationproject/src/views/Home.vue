<template>
  <!-- <div id="app"> -->
  <section>
    <!-- <div class="tableActionButtons">
      <button class="fillBtn"  id="typeOfAction">Upload Document</button>
    </div> -->
    <div class="home-main" id="tool">
      <div class="home-left" id="filter">
        <NavbarLeft />
        <!-- <label>Customer</label> -->
        <ViewContractFileVue />
      </div>
      <div class="home-right">
        <NavbarRight />
        <AnalyticsFileVue />
      
        <div style="padding: 20px; padding-top: 0px;">
          <ContractsTable />
        </div>
      </div>
    </div>
  </section>
</template>

<script>
import ContractsTable from "@/components/ContractsTable.vue";
import ViewContractFileVue from "@/components/ViewContractFile.vue";
import AnalyticsFileVue from "@/components/AnalyticsFile.vue";
import NavbarLeft from "@/components/NavbarLeft.vue";
import NavbarRight from "@/components/NavbarRight.vue";
export default {
  // register the component
  name: "Home-View",
  components: { ContractsTable, ViewContractFileVue, AnalyticsFileVue, NavbarLeft, NavbarRight },
  data() {
    return {  
      value: null,
    };
  },
};
</script>
<style scoped>
.tableActionButtons {
  display: flex;
  flex-direction: row;
  gap: 8px;
  justify-content: flex-end;
  padding-bottom: 8px;
}
.fillBtn {
  background-color: #5f249f;
  color: white;
  border-radius: 0px;
  border-top-right-radius: 20px;
  padding: 5px 40px;
  transition: 0.5s ease;
  border: 1px solid #5f249f;
}
.fillBtn:hover {
  border: 1px solid #5f249f;
  color: #5f249f;
  background-color: white;
}
.form-label {
  font-size: 18px;
  font-weight: 600;
  margin-bottom: 0px;
  color: #5f249f;
}
</style>
